from setuptools import setup

setup(name='prob_distrs',
      version='0.2',
      description='Some popular probability distributions',
      packages=['prob_distrs'],
      author="Aditya Vadlamani",
      author_email = 'aditya.t.vadlamani@gmail.com',
      zip_safe=False)
